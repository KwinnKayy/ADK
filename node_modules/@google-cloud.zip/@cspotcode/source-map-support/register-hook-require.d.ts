// tslint:disable:no-useless-files

// For following usage:
//    import '@cspotcode/source-map-support/register-hook-require'
// Instead of:
//    import sourceMapSupport from '@cspotcode/source-map-support'
//    sourceMapSupport.install({hookRequire: true})

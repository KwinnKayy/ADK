export * from "./resources/index.js";
//# sourceMappingURL=resources.d.ts.map
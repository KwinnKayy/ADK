export const VERSION = '0.61.0'; // x-release-please-version
//# sourceMappingURL=version.mjs.map
declare const partialParse: (input: string) => unknown;
export { partialParse };
//# sourceMappingURL=parser.d.ts.map
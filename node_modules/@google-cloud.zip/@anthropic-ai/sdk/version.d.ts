export declare const VERSION = "0.61.0";
//# sourceMappingURL=version.d.ts.map
import { BaseAnthropic } from "../client.js";
export declare abstract class APIResource {
    protected _client: BaseAnthropic;
    constructor(client: BaseAnthropic);
}
//# sourceMappingURL=resource.d.ts.map
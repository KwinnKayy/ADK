/**
 * Model-specific timeout constraints for non-streaming requests
 */
export declare const MODEL_NONSTREAMING_TOKENS: Record<string, number>;
//# sourceMappingURL=constants.d.ts.map
export declare const toBase64: (data: string | Uint8Array | null | undefined) => string;
export declare const fromBase64: (str: string) => Uint8Array;
//# sourceMappingURL=base64.d.ts.map
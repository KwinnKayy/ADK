/**
 * https://stackoverflow.com/a/2117523
 */
export declare let uuid4: () => any;
//# sourceMappingURL=uuid.d.ts.map
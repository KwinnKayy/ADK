# AI SDK - Provider Language Model Specification

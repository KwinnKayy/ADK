"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.version = void 0;
exports.version = {
    major: 4,
    minor: 1,
    patch: 12,
};

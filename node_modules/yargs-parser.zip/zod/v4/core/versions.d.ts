export declare const version: {
    readonly major: 4;
    readonly minor: 1;
    readonly patch: number;
};

// @ts-ignore TS6133
import { test } from "vitest";

test("masking test", () => {});

# Installation
> `npm install --save @types/tedious`

# Summary
This package contains type definitions for tedious (http://tediousjs.github.io/tedious/).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tedious.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 15:11:36 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Rogier Schouten](https://github.com/rogierschouten), [Chris Thompson](https://github.com/cjthompson), [Guilherme Amorim](https://github.com/guiampm), and [Simon Childs](https://github.com/csharpsi).

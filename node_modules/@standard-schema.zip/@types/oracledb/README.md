# Installation
> `npm install --save @types/oracledb`

# Summary
This package contains type definitions for oracledb (https://github.com/oracle/node-oracledb).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/oracledb.

### Additional Details
 * Last updated: Wed, 23 Oct 2024 03:19:49 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Connor Fitzgerald](https://github.com/connorjayfitzgerald), [Dan Beglin](https://github.com/dannyb648), and [Jacob Wheale](https://github.com/jacobwheale).

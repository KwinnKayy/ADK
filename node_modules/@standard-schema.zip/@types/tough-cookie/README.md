# Installation
> `npm install --save @types/tough-cookie`

# Summary
This package contains type definitions for tough-cookie (https://github.com/salesforce/tough-cookie).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/tough-cookie.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 20:08:00 GMT
 * Dependencies: none

# Credits
These definitions were written by [Leonard Thieu](https://github.com/leonard-thieu), [LiJinyao](https://github.com/LiJinyao), and [Michael Wei](https://github.com/no2chem).

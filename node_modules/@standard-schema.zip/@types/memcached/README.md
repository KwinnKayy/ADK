# Installation
> `npm install --save @types/memcached`

# Summary
This package contains type definitions for memcached (https://github.com/3rd-Eden/memcached).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/memcached.

### Additional Details
 * Last updated: Tue, 07 Nov 2023 09:09:39 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [KentarouTakeda](https://github.com/KentarouTakeda).

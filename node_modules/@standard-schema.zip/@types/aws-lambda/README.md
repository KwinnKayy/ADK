# Installation
> `npm install --save @types/aws-lambda`

# Summary
This package contains type definitions for aws-lambda (http://docs.aws.amazon.com/lambda).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/aws-lambda.

### Additional Details
 * Last updated: Sat, 19 Jul 2025 08:38:38 GMT
 * Dependencies: none

# Credits
These definitions were written by [James Darbyshire](https://github.com/darbio), [Michael Skarum](https://github.com/skarum), [Stef Heyenrath](https://github.com/StefH), [Rich Buggy](https://github.com/buggy), [wwwy3y3](https://github.com/wwwy3y3), [Ishaan Malhi](https://github.com/OrthoDex), [Michael Marner](https://github.com/MichaelMarner), [Daniel Cottone](https://github.com/daniel-cottone), [Kostya Misura](https://github.com/kostya-misura), [Markus Tacker](https://github.com/coderbyheart), [Palmi Valgeirsson](https://github.com/palmithor), [Danilo Raisi](https://github.com/daniloraisi), [Simon Buchan](https://github.com/simonbuchan), [David Hayden](https://github.com/Haydabase), [Chris Redekop](https://github.com/repl-chris), [Aneil Mallavarapu](https://github.com/aneilbaboo), [Jeremy Nagel](https://github.com/jeznag), [Louis Larry](https://github.com/louislarry), [Daniel Papukchiev](https://github.com/dpapukchiev), [Oliver Hookins](https://github.com/ohookins), [Trevor Leach](https://github.com/trevor-leach), [James Gregory](https://github.com/jagregory), [Erik Dalén](https://github.com/dalen), [Loïk Gaonac'h](https://github.com/loikg), [Roberto Zen](https://github.com/skyzenr), [Grzegorz Redlicki](https://github.com/redlickigrzegorz), [Juan Carbonel](https://github.com/juancarbonel), [Peter McIntyre](https://github.com/pwmcintyre), [Alex Bolenok](https://github.com/alex-bolenok-centralreach), [Marian Zange](https://github.com/marianzange), [Alessandro Palumbo](https://github.com/apalumbo), [Sachin Shekhar](https://github.com/SachinShekhar), [Ivan Martos](https://github.com/ivanmartos), [Zach Anthony](https://github.com/zach-anthony), [Peter Savnik](https://github.com/savnik), [Benoit Boure](https://github.com/bboure), [James Lakin](https://github.com/jamesorlakin), [Ross Gerbasi](https://github.com/aphex), [Joey Kilpatrick](https://github.com/joeykilpatrick), [Luciano Manerich Junior](https://github.com/lmanerich), and [Luciano M. Taranto](https://github.com/LucianoTaranto).

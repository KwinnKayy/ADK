# Installation
> `npm install --save @types/bunyan`

# Summary
This package contains type definitions for bunyan (https://github.com/trentm/node-bunyan).

# Details
Files were exported from https://github.com/DefinitelyTyped/DefinitelyTyped/tree/master/types/bunyan.

### Additional Details
 * Last updated: Mon, 06 Nov 2023 22:41:05 GMT
 * Dependencies: [@types/node](https://npmjs.com/package/@types/node)

# Credits
These definitions were written by [Alex Mikhalev](https://github.com/amikhalev).

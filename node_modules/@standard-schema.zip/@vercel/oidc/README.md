# `@vercel/oidc`

Runtime OIDC helper methods intended to be used with your Vercel Functions

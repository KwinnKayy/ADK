export declare const sleep: (ms: number) => Promise<void>;
//# sourceMappingURL=sleep.d.ts.map
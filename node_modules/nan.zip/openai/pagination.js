"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const tslib_1 = require("./internal/tslib.js");
/** @deprecated Import from ./core/pagination instead */
tslib_1.__exportStar(require("./core/pagination.js"), exports);
//# sourceMappingURL=pagination.js.map
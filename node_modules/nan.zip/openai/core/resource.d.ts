import type { OpenAI } from "../client.js";
export declare abstract class APIResource {
    protected _client: OpenAI;
    constructor(client: OpenAI);
}
//# sourceMappingURL=resource.d.ts.map
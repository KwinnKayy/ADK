import { entityKind } from "../entity.js";
import { View } from "../sql/sql.js";
class GelViewBase extends View {
  static [entityKind] = "GelViewBase";
}
export {
  GelViewBase
};
//# sourceMappingURL=view-base.js.map
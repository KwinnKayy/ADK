const GelViewConfig = Symbol.for("drizzle:GelViewConfig");
export {
  GelViewConfig
};
//# sourceMappingURL=view-common.js.map
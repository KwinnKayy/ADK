"use strict";
async function migrate() {
  return {};
}
//# sourceMappingURL=migrator.cjs.map